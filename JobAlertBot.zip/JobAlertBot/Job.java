public class Job {

    private String title;
    private String qualification;
    private String location;

    public Job(String title, String qualification, String location) {
        this.title = title;
        this.qualification = qualification;
        this.location = location;
    }

    public String getTitle() {
        return title;
    }

    public String getQualification() {
        return qualification;
    }

    public String getLocation() {
        return location;
    }
}
