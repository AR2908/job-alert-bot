public class NotificationService {

    public static void sendNotification(String message) {
        // Future: Email / Telegram API
        System.out.println("📩 Notification Sent:");
        System.out.println(message);
    }
}
