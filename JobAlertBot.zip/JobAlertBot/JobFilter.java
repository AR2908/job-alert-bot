import java.util.List;

public class JobFilter {

    public static void filterMCAJobs(List<Job> jobs) {

        System.out.println("🔔 MCA Job Alerts:\n");

        for (Job job : jobs) {
            if (job.getQualification().equalsIgnoreCase("MCA")) {
                System.out.println("📌 Job Title : " + job.getTitle());
                System.out.println("📍 Location  : " + job.getLocation());
                System.out.println("-------------------------");
            }
        }
    }
}
