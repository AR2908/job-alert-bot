import java.util.ArrayList;
import java.util.List;

public class JobFetcher {

    public static List<Job> fetchJobs() {

        List<Job> jobs = new ArrayList<>();

        jobs.add(new Job("Java Developer", "MCA", "Remote"));
        jobs.add(new Job("Web Developer", "BCA", "Indore"));
        jobs.add(new Job("Software Engineer", "MCA", "Pune"));
        jobs.add(new Job("Data Analyst", "MBA", "Delhi"));

        return jobs;
    }
}
