import java.util.List;

public class Main {

    public static void main(String[] args) {

        System.out.println("🤖 Job Alert Bot Started...\n");

        List<Job> jobs = JobFetcher.fetchJobs();

        JobFilter.filterMCAJobs(jobs);

        NotificationService.sendNotification(
                "New MCA jobs checked successfully!"
        );
    }
}
